qtquickcontrols-nemo
====================
QML components for Nemomobile, based on QtQuickControls
# Mockups
All mockups of qtquickcontrols-nemo aviable here : https://github.com/qwazix/glacier-controls-spec
# Current status
Current status you can see on mer wiki https://wiki.merproject.org/wiki/Nemo/Glacier
# Development
If you want to be part of the development please do not hesitate
to come talk at #nemomobile IRC channel (FreeNode server)
